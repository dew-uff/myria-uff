for i in `seq 1 22`; do
    ./do_query.sh $i
done
